$(document).ready(function () {
    
    /* Image selection functionality starts here*/
    $(".productVariants li").click(function () {
        var temp = $(this).find("a").find("img").attr("src").replace("small", "large");
        $(".productVariants li").removeClass("selectedImage");
        $(this).addClass("selectedImage");
        $("#largeImage").attr("src", temp)
    })
    /* Image selection functionality ends here*/

    $(".accordion-toggle").click(function () {
        var obj = $(this);
        window.setTimeout(function () {
            if (obj.hasClass("collapsed")) {
                obj.text("COLLAPSED");
            } else {
                obj.html("EXPANDED");
            }
        }, 50);
    })
});


function selectedItem(){
    var eachItemPrice=19.95;
    var e = document.getElementById("noOfItems");
    var strUser = e.options[e.selectedIndex].value;
    var totalPrice=document.getElementById("totalPrice");
    totalPrice.innerHTML= calculate(strUser,eachItemPrice);
}

function calculate(strUser,eachItemPrice){
    return "$ "+((strUser*eachItemPrice).toFixed(2));
    
}